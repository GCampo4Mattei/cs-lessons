package com.mycompany.projdatesrvtcp;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.time.Instant;
import java.util.Date;

/**
 *
 * @author lxxi
 */
public class DayTimeSrv implements Runnable {

    ServerSocket mioSrv;
    final int DAY_TIME_PORT = 13;
    final int SRV_TIMEOUT = 10000;

    /*
    public ProjDateSrvTCP(int pPort) throws SocketException, IOException {
        int srvPort;
        srvPort = (nonNull(pPort)) ? pPort : DAY_TIME_PORT;
        this.mioSrv = new ServerSocket(srvPort);
        mioSrv.setSoTimeout(SRV_TIMEOUT);
    }
     */
    public DayTimeSrv(int pPort) throws SocketException, IOException {
        this.mioSrv = new ServerSocket(pPort);
        mioSrv.setSoTimeout(SRV_TIMEOUT);
    }

    public DayTimeSrv() throws SocketException, IOException {
        this.mioSrv = new ServerSocket(DAY_TIME_PORT);
        mioSrv.setSoTimeout(SRV_TIMEOUT);
    }

    @Override
    public void run() {

        Socket miaConnection = null;

        // 1. manda in esecuzione il server
        while (!Thread.interrupted()) {

            try {

                // mette il server in attesa della connessione da parte del client
                // long timestamp = new LocalDateTime(year, month, day, hour, minute, second).getLocalMillis();
                System.out.println("Server in attesa di connessioni (" + Instant.now().toString() + ")");
                miaConnection = mioSrv.accept();
                // se entro SRV_TIMEOUT si collega qualcuno, allora la connessione viene accettata
                // altrimenti viene sollevata un'eccezione di IOException
                
                // visualizza il socket di chi effettua la richiesta
                String clientIPAddress = miaConnection.getInetAddress().toString();
                int clientPort = miaConnection.getPort();
                System.out.println("Richiesta da parte di: " + clientIPAddress + ":" + clientPort);

                // costruisco il contenuto del pacchetto di ritorno:
                // genero lo stream in output della connessione
                OutputStream connOut = miaConnection.getOutputStream();
                // imposto il contenuto codificandolo ISO-8859-1
                OutputStreamWriter mioOut = new OutputStreamWriter(connOut, "ISO-8859-1");

                // Data e ora corrente
                Date dataOraEsatta = new Date();

                // scrivi in out
                mioOut.write(dataOraEsatta.toString() + "\r\n");
                // invia
                mioOut.flush();

                // chiudi lo stream
                mioOut.close();
                miaConnection.shutdownOutput();

                // chiudi la connessione
                miaConnection.close();

            } catch (IOException ex) {
                // Logger.getLogger(DayTimeSrv.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Nessuna connessione finora (" + Instant.now().toString() + ")");
                // ex.printStackTrace();
            } 
            finally {
                
                if (miaConnection != null) {

                    try {
                        miaConnection.shutdownOutput();
                        // chiudi la connessione
                        miaConnection.close();
                    } 
                    catch (IOException ex) {
                        ex.printStackTrace();
                    }

                }

            }

        }

        System.out.println("Server thread interrotto");

        // 2. il thread viene interrotto, il server viene spento
        try {
            mioSrv.close();
            System.out.println("Server spento");
        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }

}
