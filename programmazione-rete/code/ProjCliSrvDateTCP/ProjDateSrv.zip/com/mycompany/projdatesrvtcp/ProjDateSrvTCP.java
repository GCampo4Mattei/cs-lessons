/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.projdatesrvtcp;

import java.io.IOException;

/**
 *
 * @author lxxi
 */
public class ProjDateSrvTCP {

    public static void main(String[] args) throws InterruptedException {

        System.out.println("Start and listen...");

        int c;
        Thread srvThread;

        DayTimeSrv mioDayTimeSrv;
        try {
            mioDayTimeSrv = new DayTimeSrv();
            srvThread = new Thread(mioDayTimeSrv);
            srvThread.start();

            // mettiti in attesa che l'utente prema un pulsante
            c = System.in.read();
            // interrompi il thread
            srvThread.interrupt();
            srvThread.join();

        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }

        System.out.println("Bye");

    }

}
