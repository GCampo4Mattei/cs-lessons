/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.projdateclitcp;

import java.io.IOException;

/**
 *
 * @author gcampo
 */
public class ProjDateCliTCP {

    public static void main(String[] args) throws IOException {

        String remoteSrv;
        // int remotePort = 13;

        String dayTime;

        remoteSrv = "192.168.23.51";

        DayTimeClient myClient;
        
        try {
            System.out.println("Richiesta inviata.");

            // istanzia il client e crea la connessione
            myClient = new DayTimeClient(remoteSrv);
            
            // invoca il metodo che richiede l'ora
            dayTime = myClient.getDayTime();
            
            // pubblica l'ora inviata dal server
            System.out.println("Ora del server:" + dayTime);
            
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
