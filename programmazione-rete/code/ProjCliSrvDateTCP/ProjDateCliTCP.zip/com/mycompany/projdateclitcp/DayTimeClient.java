package com.mycompany.projdateclitcp;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

/**
 *
 * @author gcampo
 */
public class DayTimeClient {

    String srvName;
    int srvPort;
    private final int DEFAULT_SRV_PORT = 13;

    public DayTimeClient(String pSrvName, int pSrvPort) {
        this.srvName = pSrvName;
        this.srvPort = pSrvPort;
    }

    public DayTimeClient(String pSrvName) {
        this.srvName = pSrvName;
        this.srvPort = DEFAULT_SRV_PORT;
    }

    public String getDayTime() throws IOException {

        String myAnswer = "";

        // struttura per la ricezione della risposta
        // crea uno stream in input ed un buffer
        InputStream myInputStream;
        int n;
        String myFragment;
        byte[] myBuffer = new byte[1024];

        // socket del server a cui connettersi
        InetSocketAddress srvSocket = new InetSocketAddress(srvName, srvPort);

        try (
                // creazione del client; la sua azione va in timeout se non eseguita entro 2s
                Socket cliSocket = new Socket()) {
            cliSocket.setSoTimeout(2000);
            // richiesta connessione; attesa max per la risposta: 3s
            cliSocket.connect(srvSocket, 3000);
            System.out.println("Connesso al server");
            // stream in input per la ricezione dei dati
            myInputStream = cliSocket.getInputStream();
            // continua a leggere dal buffer e restituisce il numero di byte letti (n)
            // fino a quando non legge più niente (= -1)
            while ((n = myInputStream.read(myBuffer)) != -1) {
                myFragment = new String(myBuffer, 0, n, "ISO-8859-1");
                myAnswer = myAnswer + myFragment;
            }

            // chiusura dello stream di ricezione dei dati
            myInputStream.close();
            // chiusura del socket di connessione al server
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return myAnswer;
    }

}
